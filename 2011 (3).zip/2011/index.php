<?php
function load_products_from_ini($filename) {
    $products = parse_ini_file($filename, true);
    return $products;
}
function display_product_card($product) {
    echo "<div style='border: 1px solid #ccc; padding: 15px; margin: 10px; width: 300px;'>";
    echo "<h2>{$product['name']}</h2>";
    echo "<p>Описание: {$product['description']}</p>";
    echo "<p>Цена: {$product['price']} ₽</p>";
    echo "<p>В наличии: {$product['stock']} шт.</p>";
    echo "<p>ID товара: {$product['id']}</p>";
    echo "</div>";
}
function display_all_products($products) {
    echo "<div style='display: flex; flex-wrap: wrap;'>";
    foreach ($products as $product) {
        display_product_card($product);
    }
    echo "</div>";
}
$filename = 'products.ini';
$products = load_products_from_ini($filename);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>\Document</title>
</head>
<body>
    <h1>Каталог</h1>
    <?php display_all_products($products); ?>
</body>
</html>